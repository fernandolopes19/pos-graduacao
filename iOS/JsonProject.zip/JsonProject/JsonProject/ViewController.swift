//
//  ViewController.swift
//  JsonProject
//
//  Created by Aluno on 06/04/2019.
//  Copyright © 2019 fernando. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage

class ViewController: UIViewController, UITableViewDataSource {
    
    @IBOutlet weak var vrTableView: UITableView!
    var company: Empresa?
    
    func parseJson(){
        Alamofire.request("http://silvanomalfattiml.000webhostapp.com/cardapio.json").responseJSON{
            response in
            
            if let json = response.result.value as? [String:Any]{
                if let nome = json["company_name"] as? String,
                    let address = json["address"] as? String,
                    let longitude = json["longitude"] as? NSString,
                    let latitude = json["latitude"] as? NSString,
                    let listItens = json["itens"] as? [[String:Any]]{
                    var company = Empresa(nome: nome,
                                          endereco: address,
                                          latitude: latitude.doubleValue,
                                          longitude: longitude.doubleValue)
                    
                    for item in listItens{
                        if let classification = item["classification"] as? NSString,
                            let image = item["image"] as? String,
                            let itemName = item["item_name"] as? String{
                            
                            let novoItem = Item(classification: classification.integerValue, image: image, itemName: itemName)
                            
                            company.listItens.append(novoItem)
                        }
                    }
                    
                    self.company = company
                    self.vrTableView.reloadData()
                }
            }
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let company = self.company{
            return company.listItens.count
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = vrTableView.dequeueReusableCell(withIdentifier: "cell") as! StarCell
        let item = company?.listItens[indexPath.row]
        
        cell.vrLabel.text = item?.itemName
        
        cell.vrEstrela1.isHighlighted = false
        cell.vrEstrela2.isHighlighted = false
        cell.vrEstrela3.isHighlighted = false
        
        if(item?.classification == 1){
            cell.vrEstrela1.isHighlighted = true
            cell.vrEstrela2.isHighlighted = false
            cell.vrEstrela3.isHighlighted = false
        } else if (item?.classification == 2){
            cell.vrEstrela1.isHighlighted = true
            cell.vrEstrela2.isHighlighted = true
            cell.vrEstrela3.isHighlighted = false
        } else {
            cell.vrEstrela1.isHighlighted = true
            cell.vrEstrela2.isHighlighted = true
            cell.vrEstrela3.isHighlighted = true
        }
        
        cell.selectionStyle = .none
        
        let remoteImageURL = URL(string: (item?.image)!)!
        
        cell.vrImagem.af_setImage(withURL: remoteImageURL)
        
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        parseJson()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
