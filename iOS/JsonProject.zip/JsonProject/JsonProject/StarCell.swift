//
//  StarCell.swift
//  JsonProject
//
//  Created by Aluno on 06/04/2019.
//  Copyright © 2019 fernando. All rights reserved.
//

import UIKit

class StarCell: UITableViewCell {

    @IBOutlet weak var vrEstrela1: UIImageView!
    @IBOutlet weak var vrEstrela2: UIImageView!
    @IBOutlet weak var vrEstrela3: UIImageView!
    @IBOutlet weak var vrLabel: UILabel!
    @IBOutlet weak var vrImagem: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
