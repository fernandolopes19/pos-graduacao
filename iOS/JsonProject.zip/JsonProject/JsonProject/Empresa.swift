//
//  Empresa.swift
//  JsonProject
//
//  Created by Aluno on 05/04/2019.
//  Copyright © 2019 fernando. All rights reserved.
//

import UIKit

class Empresa: NSObject {
    
    var nome: String
    var endereco: String
    var latitude: Double
    var longitude: Double
    var listItens: [Item] = []
    
    init(nome: String, endereco: String, latitude: Double, longitude: Double) {
        self.nome = nome
        self.endereco = endereco
        self.latitude = latitude
        self.longitude = longitude
    }
}
