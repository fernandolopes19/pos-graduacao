//
//  ViewController.swift
//  ProjetoBD
//
//  Created by Aluno on 06/04/2019.
//  Copyright © 2019 fernando. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    var contexto: NSManagedObjectContext{
        // Obtém uma referência para o objeto da classe AppDelegate
        let delegate = UIApplication.shared.delegate as! AppDelegate
        
        // Retorna o objeto responsável pelo gerenciamento de Objetos persistentes
        return delegate.persistentContainer.viewContext
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

