//
//  FormViewController.swift
//  ProjetoBD
//
//  Created by Aluno on 06/04/2019.
//  Copyright © 2019 fernando. All rights reserved.
//

import UIKit

class FormViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var vrPhoto: UIImageView!
    @IBOutlet weak var vrNome: UITextField!
    @IBOutlet weak var vrPhone: UITextField!
    @IBAction func handlePhoto(_ sender: Any) {
        let photo = UIImagePickerController()
        
        // usado para celular
        // photo.sourceType = .camera
        
        // usado para emulador
        photo.sourceType = .savedPhotosAlbum
        photo.delegate = self
        self.present(photo, animated: true, completion: nil)
    }
    
    // Método do protocolo UIPickerController que é chamado após a escolha da foto
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        // Busca os dados da imagem do dicionário
        let photo = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        // Seta o ImageView para a imagem escolhida
        vrPhoto.image = photo
        
        // Garante a saída do picker da tela
        picker.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
