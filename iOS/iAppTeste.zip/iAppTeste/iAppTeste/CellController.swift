//
//  CellController.swift
//  iAppTeste
//
//  Created by Aluno on 22/03/2019.
//  Copyright © 2019 fernando. All rights reserved.
//

import UIKit

class CellController: UITableViewCell {
    
    @IBOutlet weak var vrImageView: UIImageView!
    @IBOutlet weak var vrLabel: UILabel!
}
