//
//  main.swift
//  Aula 02
//
//  Created by Aluno on 09/03/2019.
//  Copyright © 2019 fernando. All rights reserved.
//

import Foundation
// func <nome_func> (parametro, parametro, ...) -> retorno

print("=================")
print("Função com ou sem Rótulo")
print("=================")

// Função com Rótulo
func calcMediaComRotulo(nota1:Float, nota2:Float)->Float{
    return (nota1+nota2)/2
}
let mediaComRotulo = calcMediaComRotulo(nota1: 8.6, nota2: 9.2)

// Função sem Rótulo
// O underline '_' serve para dizer que quando for chamar a função, não precisa passar o label com os parâmetros
func calcMediaSemRotulo(_ nota1:Float, nota2:Float)->Float{
    return (nota1+nota2)/2
}
let mediaSemRotulo = calcMediaSemRotulo(8.2, nota2:7.4)

//Função com e sem rótulo alternado
func metodoComValores(_ nota1:Int=7, nota2:Int=7, _ nota3:Int=7){
    print(nota1)
    print(nota2)
    print(nota3)
}
//metodoComValores(2,2) // o segundo parâmetro é da nota3
metodoComValores(nota2:4,5) // 5 é o valor para nota3

print("\n\n=================")
print("Chama função outra função já passando o parâmetro, sem explicitar a chamada e o parâmetro")
print("=================")
func calculo(valor:Int)->Int{
    return valor*valor
}
var calculaQuadrado:(Int)->Int = calculo // chama método calculo passando o valor Int
let quad = calculaQuadrado(9)
print("quadrado: ",quad)

// O que vem por aí? 🤔
print("\n\n=================")
print("Passando função como parâmetro")
print("=================")
func soma(valor1:Int, valor2:Int)->Int{
    return valor1+valor2
}

func multiplica(valor1:Int, valor2:Int)->Int{
    return valor1*valor2
}

// Passa qualquer função como parâmetro
func realizaCalculo(valor1:Int, valor2:Int, funcao:(Int, Int)->Int)->Int{
    return funcao(valor1, valor2);
}
let calculo1 = realizaCalculo(valor1: 4, valor2: 2, funcao: soma)
let calculo2 = realizaCalculo(valor1: 4, valor2: 2, funcao: multiplica)
print("soma: ", calculo1)
print("multiplicação: ", calculo2)


// CLASSE

print("\n\n=================")
print("Classe")
print("=================")
class ClasseSwift{
    
    // Stored Property
    private var _nome:String
    private var _PI:Float = 3.1415
    
    //Computed Property
    var nome:String{
        get{
            return _nome
        }
        
        set{
            _nome = newValue
        }
    }
    
    var PI:Float{
        get{
            return _PI
        }
    }
    
    // convenience serve para falar que um inicializador chama outro inicializador
    convenience init(){
        self.init(nome:"UFG")
    }
    
    // Sobrecarga é determinada pelo rótulo
    init(nome:String){
        _nome = nome
    }
    
    // init? = Significa que eeste init pode falhar. Pode ser usado para testar se o parâmetro é do mesmo tipo aceito pelo inicializador
    convenience init?(nomeParam:String){
        if (nomeParam.count == 0){
            return nil
        }
        
        self.init(nome:nomeParam)
    }
    
    // Deinicializador
    deinit{
        print("ESTE OBJETO FOI DESTRUÍDO")
    }
}
// Quase igual PYTHON
var novoObjeto = ClasseSwift()
print(novoObjeto.nome)
novoObjeto.nome = "iOS aula 2"
print(novoObjeto.nome)

let testaTipo = novoObjeto is ClasseSwift
print("teste tipo classe: ", testaTipo)

// Objeto é destruído quando não há mais nada apontando para ele
print("\nantes do novo objeto")
novoObjeto = ClasseSwift()
print("novo objeto")

print("\n\n=================")
print("Classe 2")
print("=================")

// weak: Fala que a variável que está apontando é fraca. Isso significa que, quando o objeto não for mais usado, a referência para o outro objecto será destruída

// Se retirar as anotações, um objeto fica apontando para o outro, e essa é referência forte,
// então nenhum objeto será destruído, mas eles não poderão mais ser acessados, gerando um
// lixo na memória
// Retirando os 'weak': não será chamado o deinit
class Automovel {
    var nome: String
    weak var proprietario:Proprietario?
    
    init(nome:String){
        self.nome = nome
    }
    
    deinit {
        print("ESTE AUTOMÓVEL FOI DESTRUÍDO")
    }
}

class Proprietario {
    var nome: String
    weak var automovel: Automovel?
    
    init(nome:String){
        self.nome = nome
    }
    
    deinit {
        print("ESTE PROPRIETÁRIO BATEU AS 👢👢")
    }
}

var marceloQuinta:Proprietario? = Proprietario(nome:"Marcelo Quinta")
var carroMarcelo:Automovel? = Automovel(nome:"Samurai")

marceloQuinta?.automovel = carroMarcelo
carroMarcelo?.proprietario = marceloQuinta

carroMarcelo = nil
marceloQuinta = nil


print("\n\n=================")
print("Classe e Protocol (Interface Java)")
print("=================")

// protocol: Tipo Interface no java
protocol Tecnico {
    func tomaCafe()
}
class Empregado {
    func calculaSalario()->Float{
        return 987;
    }
}

class Programador:Empregado, Tecnico{
    var totalProjetos:Float = 2
    override func calculaSalario() -> Float {
        return super.calculaSalario() + totalProjetos * Float(500)
    }
    
    func tomaCafe() {
        <#code#>
    }
}

var generico = Empregado()
var escravo = Programador()
generico = escravo

if(generico is Programador){
    //var convertido = generico as? Programador // ? : pode retornar nil
    var convertido = generico as! Programador // ! : assume que a variável foi instanciada e que não vai ter erro
}

print("\n\n=================")
print("Tipo Genérico")
print("=================")

//
class Pilha<T> {
    // Declara um array genérico
    var pilha: [T]
    
    // Inicializa o array genérico vazio
    init(){
        pilha = [T]()
    }
    
    // Cria um método com parâmetro genérico
    func push(dado: T){
        pilha.append(dado)
    }
    
    // Cria um método com retorno genérico
    func pop() -> T{
        return pilha.removeLast()
    }
}





