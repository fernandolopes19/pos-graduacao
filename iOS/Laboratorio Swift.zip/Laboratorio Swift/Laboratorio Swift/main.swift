//
//  main.swift
//  Laboratorio Swift
//
//  Created by Aluno on 08/03/2019.
//  Copyright © 2019 fernando. All rights reserved.
//

import Foundation

//TypeSafe e TypeInfearance
let carro = ("Ford", "F250", "2005", "ABC1234")
let pc = (Processador:"intel i5 8600k", RAM:"Corsair Vengeance 2x8gb 3200MHz", HD:"2TB")

print("\(carro.0) \(carro.1) \(carro.2) \(carro.3)")
print("\(pc.Processador) \(pc.RAM) \(pc.HD)")

// variável com anotação do tipo ? pode não ser inicializada, mas se não for inicializada antes de ser usada, ela será atribuída como nula (nil)
var tipoPerigoso:Int? = Int("1234")
print("\(tipoPerigoso!)")

// variável com anotação do tipo ! pode não ser inicializada, mas antes de ser usado, tem que ser inicializada
var tipoPerigosoVerificado:Int! = Int("1234")
if tipoPerigoso != nil
{
    print("\(tipoPerigosoVerificado)")
}

// Forma mais comum de fazer o UNWRAPPER de um tipo optional
if let conversao = tipoPerigoso
{
    print("\(conversao)")
}
else
{
    print("Algo deu errado")
}
//======================
//COLEÇÕES DE DADOS
//======================
//ARRAYS
//DICIONARIOS
//CONJUNTOS

print("\n\n========== ARRAYS ==========")
var vetor = ["Java", "C++", "Python", "Swift", "Go"]
vetor.append("Javascript")
vetor += ["C", "Pascal", "Delphi"]
print(vetor)
print("subconjunto \(vetor[1...4])") // intervalo fechado
print("subconjunto \(vetor[1..<4])") // intervalo aberto no 4
print("\(vetor.count) elementos")
var vetorTipado: [String] = []
var vetorVazio = [String]()

let vetorFixo = ["UFG", "UFT", "UFRJ"]
// não pode usar vetorFixo.append(...) porque é fixo

print("\n\n========== FOR EACH ==========")
for linguagem in vetor
{
    print("\(linguagem)")
}

print("\n\n========== DICIONARIO ==========")
let dicionario:[String:String] = [:]

var times = ["Gremio":"RS", "São Paulo":"SP", "Ibis":"PE"]

var variosTimes: [String:[String]] = [:]
variosTimes = ["RS":["Gremio", "Caxias", "Juventude", "Internacional"], "SP": ["São Paulo", "Palmeiras", "Santos"]]
print("RS = \(variosTimes["RS"]![0])")
print("SP = \(variosTimes["SP"]!)")

for time in variosTimes.values
{
    print("times: \(time)")
}
for chave in variosTimes.keys
{
    print("chaves: \(chave)")
}

// =================
// FUNÇÕES
// =================

func retornaPi()->Float
{
    return 3.1415
}

// Sem retorno
func funcaoVoid()
{
    
}

// retorna tupla
func retornoMultiplo()->(String, Int)
{
    return ("UFG", 2019)
}
